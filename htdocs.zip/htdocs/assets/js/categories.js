const categories = { ais3: [{ url: `/~b12902079/AIS3-2024-pre-exam-writeup/`, date: `10 Aug 2024`, title: `AIS3 2024 Pre-exam`},],ctf: [{ url: `/~b12902079/picoCTF-droids/`, date: `27 Jan 2025`, title: `picoCTF droids`},{ url: `/~b12902079/aegisCTF-2024/`, date: `21 Sep 2024`, title: `2024神盾盃`},{ url: `/~b12902079/Sekai-CTF-2024/`, date: `25 Aug 2024`, title: `Sekai CTF 2024`},{ url: `/~b12902079/AIS3-2024-pre-exam-writeup/`, date: `10 Aug 2024`, title: `AIS3 2024 Pre-exam`},],writeup: [{ url: `/~b12902079/pwnable-xyz-Free-Spirit/`, date: `26 Feb 2025`, title: `pwnable.xyz Free-Spirit`},{ url: `/~b12902079/pwnable-tw-Start/`, date: `21 Feb 2025`, title: `pwnable.tw Start`},{ url: `/~b12902079/picoCTF-droids/`, date: `27 Jan 2025`, title: `picoCTF droids`},{ url: `/~b12902079/HTML-2024-Fall-Final-Project/`, date: `22 Dec 2024`, title: `HTML 2024 Fall: Data Leakage Solution`},{ url: `/~b12902079/aegisCTF-2024/`, date: `21 Sep 2024`, title: `2024神盾盃`},{ url: `/~b12902079/Sekai-CTF-2024/`, date: `25 Aug 2024`, title: `Sekai CTF 2024`},{ url: `/~b12902079/HITCON-2024-x-DEVCORE-Wargame/`, date: `12 Aug 2024`, title: `HITCON 2024 x DEVCORE Wargame`},{ url: `/~b12902079/AIS3-2024-pre-exam-writeup/`, date: `10 Aug 2024`, title: `AIS3 2024 Pre-exam`},],exploit_education: [{ url: `/~b12902079/Exploit-Education-Phoenix-Stack/`, date: `12 Aug 2024`, title: `Exploit Education: Phoenix - Stack`},],ntu: [{ url: `/~b12902079/HTML-2024-Fall-Final-Project/`, date: `22 Dec 2024`, title: `HTML 2024 Fall: Data Leakage Solution`},],pwnableTW: [{ url: `/~b12902079/pwnable-tw-Start/`, date: `21 Feb 2025`, title: `pwnable.tw Start`},],pwnableXYZ: [{ url: `/~b12902079/pwnable-xyz-Free-Spirit/`, date: `26 Feb 2025`, title: `pwnable.xyz Free-Spirit`},], }

console.log(categories)

window.onload = function () {
  document.querySelectorAll(".category").forEach((category) => {
    category.addEventListener("click", function (e) {
      const posts = categories[e.target.innerText.replace(" ","_")];
      let html = ``
      posts.forEach(post=>{
        html += `
        <a class="modal-article" href="${post.url}">
          <h4>${post.title}</h4>
          <small class="modal-article-date">${post.date}</small>
        </a>
        `
      })
      document.querySelector("#category-modal-title").innerText = e.target.innerText;
      document.querySelector("#category-modal-content").innerHTML = html;
      document.querySelector("#category-modal-bg").classList.toggle("open");
      document.querySelector("#category-modal").classList.toggle("open");
    });
  });

  document.querySelector("#category-modal-bg").addEventListener("click", function(){
    document.querySelector("#category-modal-title").innerText = "";
    document.querySelector("#category-modal-content").innerHTML = "";
    document.querySelector("#category-modal-bg").classList.toggle("open");
    document.querySelector("#category-modal").classList.toggle("open");
  })
};