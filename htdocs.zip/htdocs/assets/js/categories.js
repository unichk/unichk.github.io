const categories = { ais3: [{ url: `/~unicorn/AIS3-2024-pre-exam-writeup/`, date: `10 Aug 2024`, title: `AIS3 2024 Pre-exam`},],ctf: [{ url: `/~unicorn/picoCTF-droids/`, date: `27 Jan 2025`, title: `picoCTF droids`},{ url: `/~unicorn/aegisCTF-2024/`, date: `21 Sep 2024`, title: `2024神盾盃`},{ url: `/~unicorn/Sekai-CTF-2024/`, date: `25 Aug 2024`, title: `Sekai CTF 2024`},{ url: `/~unicorn/AIS3-2024-pre-exam-writeup/`, date: `10 Aug 2024`, title: `AIS3 2024 Pre-exam`},],writeup: [{ url: `/~unicorn/picoCTF-droids/`, date: `27 Jan 2025`, title: `picoCTF droids`},{ url: `/~unicorn/HTML-2024-Fall-Final-Project/`, date: `22 Dec 2024`, title: `HTML 2024 Fall: Data Leakage Solution`},{ url: `/~unicorn/aegisCTF-2024/`, date: `21 Sep 2024`, title: `2024神盾盃`},{ url: `/~unicorn/Sekai-CTF-2024/`, date: `25 Aug 2024`, title: `Sekai CTF 2024`},{ url: `/~unicorn/HITCON-2024-x-DEVCORE-Wargame/`, date: `12 Aug 2024`, title: `HITCON 2024 x DEVCORE Wargame`},{ url: `/~unicorn/AIS3-2024-pre-exam-writeup/`, date: `10 Aug 2024`, title: `AIS3 2024 Pre-exam`},],exploit_education: [{ url: `/~unicorn/Exploit-Education-Phoenix-Stack/`, date: `12 Aug 2024`, title: `Exploit Education: Phoenix - Stack`},],ntu: [{ url: `/~unicorn/HTML-2024-Fall-Final-Project/`, date: `22 Dec 2024`, title: `HTML 2024 Fall: Data Leakage Solution`},], }

console.log(categories)

window.onload = function () {
  document.querySelectorAll(".category").forEach((category) => {
    category.addEventListener("click", function (e) {
      const posts = categories[e.target.innerText.replace(" ","_")];
      let html = ``
      posts.forEach(post=>{
        html += `
        <a class="modal-article" href="${post.url}">
          <h4>${post.title}</h4>
          <small class="modal-article-date">${post.date}</small>
        </a>
        `
      })
      document.querySelector("#category-modal-title").innerText = e.target.innerText;
      document.querySelector("#category-modal-content").innerHTML = html;
      document.querySelector("#category-modal-bg").classList.toggle("open");
      document.querySelector("#category-modal").classList.toggle("open");
    });
  });

  document.querySelector("#category-modal-bg").addEventListener("click", function(){
    document.querySelector("#category-modal-title").innerText = "";
    document.querySelector("#category-modal-content").innerHTML = "";
    document.querySelector("#category-modal-bg").classList.toggle("open");
    document.querySelector("#category-modal").classList.toggle("open");
  })
};